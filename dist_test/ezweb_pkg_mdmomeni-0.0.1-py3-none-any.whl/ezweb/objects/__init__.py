from ezweb.objects.soup import EzSoup
