import sys , os
sys.path.append(os.getcwd())

from ezweb import EzSoup
from ezweb.utils.http import safe_get



url = "https://www.zoomit.ir/graphic/373935-next-generation-amd-radeon-rx-7600-rx-7500-refreshed-6nm-navi-2x-gpus/"
# response = safe_get(url)

# with open("cache_persian.html" , "w" , encoding="utf-8") as f :
#     f.write(response.text)


# soup = EzSoup.from_url(url)
with open("cache_persian.html" , "r" , encoding="utf-8") as f :
    soup = EzSoup(f.read())

# # print(soup.main_text)
# # print(soup.json_summary)
soup.save_content_summary_json()

